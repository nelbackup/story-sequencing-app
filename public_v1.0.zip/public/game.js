let currentStory = null;
let timerInterval = null;
let remainingSeconds = 60;
let practiceCount = 0;

document.addEventListener('DOMContentLoaded', async () => {
  await loadStories();
  setupPracticeCounter();
});

async function loadStories() {
  const res = await fetch('/api/stories');
  const stories = await res.json();
  if (stories.length > 0) {
    initGame(stories[0]); // Load the first set
  } else {
    document.getElementById('storyPrompt').innerText = '無可用故事題目，請至管理後台新增。';
  }
}

function initGame(story) {
  currentStory = story;
  document.getElementById('storyPrompt').innerText = story.prompt || '請按順序排列圖片，然後講述故事。';
  remainingSeconds = story.durationSeconds || 60;
  
  if (story.audioUrl) {
    const audioEl = document.getElementById('storyAudio');
    audioEl.src = story.audioUrl;
    document.getElementById('playAudioBtn').onclick = () => audioEl.play();
  } else {
    document.getElementById('playAudioBtn').style.display = 'none';
  }

  startTimer();
  renderSlots(story.cards.length);
  renderCards(story.cards);
}

function startTimer() {
  clearInterval(timerInterval);
  updateTimerDisplay();
  timerInterval = setInterval(() => {
    if (remainingSeconds > 0) {
      remainingSeconds--;
      updateTimerDisplay();
    } else {
      clearInterval(timerInterval);
      alert('時間到！');
    }
  }, 1000);
}

function updateTimerDisplay() {
  const mins = String(Math.floor(remainingSeconds / 60)).padStart(2, '0');
  const secs = String(remainingSeconds % 60).padStart(2, '0');
  document.getElementById('timerText').innerText = `${mins}:${secs}`;
}

function renderSlots(count) {
  const container = document.getElementById('slotsContainer');
  container.innerHTML = '';
  for (let i = 0; i < count; i++) {
    const slot = document.createElement('div');
    slot.className = 'drop-slot';
    slot.dataset.slotIndex = i + 1;

    slot.addEventListener('dragover', e => {
      e.preventDefault();
      slot.classList.add('drag-over');
    });
    slot.addEventListener('dragleave', () => slot.classList.remove('drag-over'));
    slot.addEventListener('drop', e => handleDrop(e, slot));

    container.appendChild(slot);
  }
}

function renderCards(cards) {
  const board = document.getElementById('cardsBoard');
  board.innerHTML = '';
  
  // Shuffle cards for placement
  const shuffled = [...cards].sort(() => Math.random() - 0.5);

  shuffled.forEach((card, idx) => {
    const cardEl = document.createElement('div');
    cardEl.className = 'card-item';
    cardEl.draggable = true;
    cardEl.id = card.id;
    cardEl.dataset.correctOrder = card.correctOrder;

    cardEl.innerHTML = `
      <div class="card-number">${idx + 1}</div>
      <img src="${card.imageUrl}" alt="Card image">
    `;

    cardEl.addEventListener('dragstart', (e) => {
      e.dataTransfer.setData('text/plain', card.id);
    });

    board.appendChild(cardEl);
  });
}

function handleDrop(e, slot) {
  e.preventDefault();
  slot.classList.remove('drag-over');
  const cardId = e.dataTransfer.getData('text/plain');
  const cardEl = document.getElementById(cardId);

  // If slot already has a card, swap back to cards board
  if (slot.children.length > 0) {
    document.getElementById('cardsBoard').appendChild(slot.children[0]);
  }
  slot.appendChild(cardEl);
}

// Verification Logic
document.getElementById('checkOrderBtn').addEventListener('click', () => {
  const slots = document.querySelectorAll('.drop-slot');
  let isComplete = true;
  let isCorrect = true;

  slots.forEach((slot, index) => {
    const card = slot.querySelector('.card-item');
    if (!card) {
      isComplete = false;
      return;
    }
    const expected = index + 1;
    if (parseInt(card.dataset.correctOrder, 10) !== expected) {
      isCorrect = false;
    }
  });

  if (!isComplete) {
    alert('請將所有卡片排入左側卡槽中！');
    return;
  }

  if (isCorrect) {
    alert('恭喜你！排序完全正確！🎉');
  } else {
    alert('排序有誤，請再仔細聽聽音頻重新調整！');
  }
});

function setupPracticeCounter() {
  const countEl = document.getElementById('practiceCount');
  document.getElementById('incCount').onclick = () => { practiceCount++; countEl.innerText = practiceCount; };
  document.getElementById('decCount').onclick = () => { 
    if (practiceCount > 0) practiceCount--; 
    countEl.innerText = practiceCount; 
  };
}